# GENERATED VERSION FILE
# TIME: Mon Oct 12 09:25:09 2020

__version__ = '0.3.0+038435e'
short_version = '0.3.0'
